from project.fruit import Fruit


orange = Fruit("Orange", "2024-10-30")
a = 5