from project.dog import Dog
from project.cat import Cat

c = Cat()

print(c.eat())
print(c.meow())

d = Dog()
print(d.eat())
print(d.bark())
