from project.sports_car import SportsCar


s = SportsCar()
print(s.race())
print(s.drive())
print(s.move())